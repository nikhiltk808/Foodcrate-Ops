import sqlite3

# This connects to your database file
db_path = "zion_ops.db"

def fix_database():
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check if 'lat' column exists
        cursor.execute("PRAGMA table_info(attendance)")
        columns = [info[1] for info in cursor.fetchall()]
        
        print(f"Current columns: {columns}")

        # Add the missing columns if they aren't there
        if 'lat' not in columns:
            print("Fixing Database: Adding 'lat' column...")
            cursor.execute("ALTER TABLE attendance ADD COLUMN lat TEXT")
            
        if 'lon' not in columns:
            print("Fixing Database: Adding 'lon' column...")
            cursor.execute("ALTER TABLE attendance ADD COLUMN lon TEXT")
            
        conn.commit()
        conn.close()
        print("✅ SUCCESS: Database fixed! You can now Check In.")
        
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    fix_database()