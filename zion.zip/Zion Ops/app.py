# ================= SECTION 1: IMPORTS & CONFIGURATION =================
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
import sqlite3
import json
import os
from datetime import datetime, timedelta
from pathlib import Path
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = "zion_hills_secure_key"

# --- UNIVERSAL PATH LOGIC ---
# This ensures it works on your Laptop AND PythonAnywhere without changes
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "zion_ops.db"
UPLOAD_FOLDER = BASE_DIR / "static" / "uploads"
UPLOAD_FOLDER.mkdir(parents=True, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Modern Theme Colors
THEME = {
    'primary': '#4361ee', 'secondary': '#3f37c9', 'success': '#10b981',
    'warning': '#f59e0b', 'bg': '#f3f4f6', 'card': '#ffffff'
}

# ================= SECTION 2: DATABASE MANAGEMENT =================
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        # Users Table
        conn.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE, pin TEXT, role TEXT, department TEXT)")
        # Attendance Table (with GPS lat/lon)
        conn.execute("CREATE TABLE IF NOT EXISTS attendance (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, action TEXT, timestamp DATETIME, lat TEXT, lon TEXT)")
        # Checklist Logs (History of submissions)
        conn.execute("CREATE TABLE IF NOT EXISTS checklist_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, checklist_id INTEGER, data TEXT, photo_path TEXT, timestamp DATETIME, edit_history TEXT)")
        # Checklists Definitions
        conn.execute("CREATE TABLE IF NOT EXISTS checklists (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, tasks TEXT, assigned_to TEXT, trigger_time TEXT, frequency TEXT)")
        
        # Create Default Admin User
        try: conn.execute("INSERT INTO users (name, pin, role, department) VALUES ('Admin', '1234', 'manager', 'Admin')")
        except sqlite3.IntegrityError: pass

# ================= SECTION 3: PAGE ROUTES (VIEWS) =================

# --- 3.1: ADMIN DASHBOARD ---
@app.route('/')
def home():
    if 'user_id' not in session: return redirect(url_for('login'))
    
    # Manager Access Only
    if session.get('user_role') == 'manager':
        with get_db() as conn:
            # 1. Date & Shift Logic
            date_str = request.args.get('date', datetime.now().strftime('%Y-%m-%d'))
            try: selected_date = datetime.strptime(date_str, '%Y-%m-%d')
            except: selected_date = datetime.now()
            
            shift_start = selected_date.replace(hour=4, minute=0, second=0, microsecond=0)
            shift_end = shift_start + timedelta(hours=24)

            # 2. Fetch Data
            users = [dict(u) for u in conn.execute("SELECT * FROM users").fetchall()]
            user_map = {u['id']: u['name'] for u in users}

            att_logs = conn.execute("SELECT * FROM attendance WHERE timestamp >= ? AND timestamp < ? ORDER BY timestamp ASC", (shift_start, shift_end)).fetchall()
            check_logs = conn.execute("SELECT * FROM checklist_logs WHERE timestamp >= ? AND timestamp < ?", (shift_start, shift_end)).fetchall()

            # 3. Timeline Data construction
            CHART_START_HOUR = 4; TOTAL_MINUTES = 24 * 60
            timeline_users = []
            
            for u in users:
                uid = u['id']
                u_logs = [dict(l) for l in att_logs if l['user_id'] == uid]
                segments = []
                current_in = None
                
                for entry in u_logs:
                    try: ts = datetime.strptime(entry['timestamp'], '%Y-%m-%d %H:%M:%S.%f')
                    except: 
                        try: ts = datetime.strptime(entry['timestamp'], '%Y-%m-%d %H:%M:%S')
                        except: continue

                    if entry['action'] == 'in':
                        if current_in is None: current_in = ts
                    elif entry['action'] == 'out':
                        if current_in:
                            start_delta = (current_in - shift_start).total_seconds() / 60
                            duration = (ts - current_in).total_seconds() / 60
                            segments.append({'left': (max(0, start_delta)/TOTAL_MINUTES)*100, 'width': (duration/TOTAL_MINUTES)*100})
                            current_in = None
                
                # Add "Live" segment if they are currently clocked in today
                if current_in and selected_date.date() == datetime.now().date():
                    start_delta = (current_in - shift_start).total_seconds() / 60
                    duration = (datetime.now() - current_in).total_seconds() / 60
                    segments.append({'left': (max(0, start_delta)/TOTAL_MINUTES)*100, 'width': (duration/TOTAL_MINUTES)*100})

                timeline_users.append({'name': u['name'], 'color': f"hsl({(uid * 137) % 360}, 70%, 80%)", 'segments': segments})
            
            timeline_hours = [(CHART_START_HOUR + i) % 24 for i in range(25)]

            # 4. Checklist Statistics
            checklist_stats = []
            all_checklists = conn.execute("SELECT * FROM checklists").fetchall()
            today_name = selected_date.strftime('%A')

            for c in all_checklists:
                c_dict = dict(c)
                freq = c_dict.get('frequency', 'Daily')
                if freq.startswith('Weekly') and today_name not in freq: continue

                assigned_ids = c['assigned_to'].split(',') if c['assigned_to'] else []
                expected_uids = set()
                if 'all' in assigned_ids: expected_uids = {u['id'] for u in users}
                else:
                    for item in assigned_ids:
                        if item.startswith('dept:'):
                            dept = item.replace('dept:', '')
                            expected_uids.update(u['id'] for u in users if u.get('department') == dept)
                        elif item.isdigit(): expected_uids.add(int(item))
                
                these_logs = [l for l in check_logs if l['checklist_id'] == c['id']]
                submitters = {l['user_id'] for l in these_logs}
                
                c_dict['submitted'] = len(submitters)
                c_dict['expected'] = len(expected_uids)
                c_dict['percent'] = int((len(submitters)/len(expected_uids))*100) if expected_uids else 0
                checklist_stats.append(c_dict)

            stats = {'present': len(set(l['user_id'] for l in att_logs))}

        return render_template('dashboard_admin.html', theme=THEME, user=session['user_name'], data=stats, timeline_users=timeline_users, timeline_hours=timeline_hours, checklist_stats=checklist_stats, selected_date=date_str, users=users)
    else:
        # If not a manager, send to staff dashboard
        return redirect(url_for('staff_dashboard'))


# --- 3.2: STAFF DASHBOARD (FIXED VARIABLES) ---
@app.route('/staff_dashboard')
def staff_dashboard():
    if 'user_id' not in session: return redirect(url_for('login'))
    
    # 1. INITIALIZE VARIABLES (Prevents NameErrors)
    user_id = str(session['user_id'])
    user_dept_tag = f"dept:{session.get('user_dept', '')}"
    now = datetime.now()
    today_str = now.strftime('%Y-%m-%d') # <-- Defined early
    
    # Initialize Accumulators
    timeline_segments = []
    events_history = []
    total_work_seconds = 0
    total_break_seconds = 0
    total_duty_seconds = 0 # <-- Required by HTML template
    
    current_status = 'out'
    last_action_time = None
    current_in_time = None
    chart_start_min = 4 * 60

    # 2. SHIFT LOGIC
    search_start = now - timedelta(hours=24)
    if now.hour < 4: 
        chart_shift_start = (now - timedelta(days=1)).replace(hour=4, minute=0, second=0)
    else: 
        chart_shift_start = now.replace(hour=4, minute=0, second=0)
    
    shift_end = chart_shift_start + timedelta(hours=24)
    today_name = chart_shift_start.strftime('%A')

    with get_db() as conn:
        logs = conn.execute("SELECT * FROM attendance WHERE user_id=? AND timestamp >= ? ORDER BY timestamp ASC", 
                          (session['user_id'], search_start)).fetchall()

        for log in logs:
            # Robust Timestamp Parsing
            try: ts = datetime.strptime(log['timestamp'], '%Y-%m-%d %H:%M:%S.%f')
            except: 
                try: ts = datetime.strptime(log['timestamp'], '%Y-%m-%d %H:%M:%S')
                except: continue

            if ts < chart_shift_start: continue

            action = log['action']
            last_action_time = ts
            
            # --- Event History Log ---
            evt_label = "Unknown"
            if action == 'in': evt_label = "Checked In"
            elif action == 'out': evt_label = "Checked Out"
            elif action == 'break_start': evt_label = "Started Break"
            elif action == 'break_end': evt_label = "Ended Break"
            events_history.append({'time': ts.strftime('%H:%M'), 'action': evt_label, 'type': action})

            # --- Timeline & Calc ---
            def get_mins(t): return (t.hour * 60 + t.minute) - chart_start_min
            
            if action == 'in':
                current_in_time = ts
                current_status = 'in'
            elif action == 'break_start':
                if current_in_time:
                    # Finalize Work Segment
                    start_m = get_mins(current_in_time)
                    if start_m < 0: start_m += (24*60)
                    dur = (ts - current_in_time).total_seconds()
                    total_work_seconds += dur
                    timeline_segments.append({'left': (start_m/1440)*100, 'width': ((dur/60)/1440)*100, 'color': '#10b981'})
                    current_in_time = None
                current_status = 'break'
            elif action == 'break_end':
                # Break duration is gap between last action (break_start) and now
                current_in_time = ts
                current_status = 'in'
            elif action == 'out':
                if current_in_time:
                    start_m = get_mins(current_in_time)
                    if start_m < 0: start_m += (24*60)
                    dur = (ts - current_in_time).total_seconds()
                    total_work_seconds += dur
                    timeline_segments.append({'left': (start_m/1440)*100, 'width': ((dur/60)/1440)*100, 'color': '#10b981'})
                    current_in_time = None
                current_status = 'out'
        
        # --- Live Calculations ---
        if current_status == 'in' and current_in_time:
            # Active Work
            start_m = (current_in_time.hour * 60 + current_in_time.minute) - chart_start_min
            if start_m < 0: start_m += (24*60)
            added_sec = (now - current_in_time).total_seconds()
            total_work_seconds += added_sec
            timeline_segments.append({'left': (start_m/1440)*100, 'width': ((added_sec/60)/1440)*100, 'color': '#4361ee'})
        
        elif current_status == 'break' and last_action_time:
            # Active Break
            total_break_seconds += (now - last_action_time).total_seconds()

        # --- Calculate COMPLETED breaks ---
        for i in range(len(logs)-1):
            if logs[i]['action'] == 'break_start' and logs[i+1]['action'] == 'break_end':
                 try:
                     # Slice [:19] safely ignores microseconds to ensure format match
                     t1 = datetime.strptime(logs[i]['timestamp'][:19], '%Y-%m-%d %H:%M:%S')
                     t2 = datetime.strptime(logs[i+1]['timestamp'][:19], '%Y-%m-%d %H:%M:%S')
                     total_break_seconds += (t2 - t1).total_seconds()
                 except: pass

        # Map work seconds to duty seconds for template compatibility
        total_duty_seconds = total_work_seconds

        shift_stats = {
            'work_str': f"{int(total_work_seconds//3600)}h {int((total_work_seconds%3600)//60)}m",
            'break_str': f"{int(total_break_seconds//3600)}h {int((total_break_seconds%3600)//60)}m",
            'total_str': f"{int((total_work_seconds+total_break_seconds)//3600)}h {int(((total_work_seconds+total_break_seconds)%3600)//60)}m"
        }

        # --- 3. CHECKLIST LOGIC ---
        all_lists = conn.execute("SELECT * FROM checklists").fetchall()
        my_lists = []
        my_logs = conn.execute("SELECT * FROM checklist_logs WHERE user_id=? AND timestamp >= ? AND timestamp < ?", 
                             (session['user_id'], chart_shift_start, shift_end)).fetchall()
        log_map = {l['checklist_id']: dict(l) for l in my_logs}

        for row in all_lists:
            r = dict(row)
            freq = r.get('frequency', 'Daily')
            if freq.startswith('Weekly') and today_name not in freq: continue

            assigned_ids = r['assigned_to'].split(',') if r['assigned_to'] else []
            is_assigned = ('all' in assigned_ids) or (user_id in assigned_ids) or (user_dept_tag in assigned_ids)
            
            if is_assigned:
                try: r['task_items'] = json.loads(r['tasks']) 
                except: r['task_items'] = []
                
                log = log_map.get(r['id'])
                r['saved_data'] = json.loads(log['data']) if (log and log['data']) else {}
                history = json.loads(log['edit_history']) if (log and log['edit_history']) else []
                r['attempt_count'] = len(history) 
                r['history'] = history
                r['log_id'] = log['id'] if log else None

                try:
                    t_hour, t_min = map(int, r['trigger_time'].split(':'))
                    trigger_dt = chart_shift_start.replace(hour=t_hour, minute=t_min)
                    if trigger_dt < chart_shift_start: trigger_dt += timedelta(days=1)
                    expiry_dt = trigger_dt + timedelta(hours=2)
                    r['expiry_timestamp'] = expiry_dt.timestamp() * 1000
                except: 
                    trigger_dt = now; expiry_dt = now + timedelta(hours=2); r['expiry_timestamp'] = 0

                is_expired = now > expiry_dt
                is_max_edits = r['attempt_count'] >= 3
                is_future = now < trigger_dt

                r['is_locked'] = False; r['lock_reason'] = ""; r['time_msg'] = "Active"
                if is_future: r['is_locked'] = True; r['lock_reason'] = f"Starts {r['trigger_time']}"; r['time_msg'] = "Upcoming"
                elif is_expired: r['is_locked'] = True; r['lock_reason'] = "Expired"; r['time_msg'] = "Expired"
                elif is_max_edits: r['is_locked'] = True; r['lock_reason'] = "Max Attempts"; r['time_msg'] = "Locked"

                if log:
                    filled = sum(1 for k in r['saved_data'].keys() if k.startswith('task_'))
                    total = len(r['task_items'])
                    r['percent'] = int((filled/total)*100) if total > 0 else 0
                else: r['percent'] = 0
                my_lists.append(r)

    return render_template('dashboard_staff.html', theme=THEME, user=session['user_name'], checklists=my_lists, current_status=current_status, total_duty_seconds=total_duty_seconds, last_action_timestamp=last_action_time.timestamp() if last_action_time else 0, timeline_segments=timeline_segments, events=events_history, stats=shift_stats)


# --- 3.3: AUTHENTICATION ---
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        name = request.form.get('name')
        pin = request.form.get('pin')
        with get_db() as conn:
            user = conn.execute("SELECT * FROM users WHERE name = ? AND pin = ?", (name, pin)).fetchone()
            if user: 
                session['user_id'] = user['id']; session['user_name'] = user['name']
                session['user_role'] = user['role']; session['user_dept'] = user['department']
                return redirect(url_for('home'))
            else: return render_template('login.html', theme=THEME, error="Invalid Name or PIN")
    return render_template('login.html', theme=THEME)

@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('login'))

# ================= SECTION 4: ADMIN UTILITIES =================
@app.route('/admin/settings')
def admin_settings():
    if 'user_id' not in session: return redirect(url_for('login'))
    with get_db() as conn:
        users = [dict(u) for u in conn.execute("SELECT * FROM users").fetchall()]
        depts_rows = conn.execute("SELECT DISTINCT department FROM users WHERE department IS NOT NULL AND department != ''").fetchall()
        departments = [row['department'] for row in depts_rows]
        lists_raw = conn.execute("SELECT * FROM checklists").fetchall()
        checklists = []
        for l in lists_raw:
            d = dict(l)
            ids = d['assigned_to'].split(',') if d['assigned_to'] else []
            if 'all' in ids: d['assigned_names'] = "Everyone"
            else:
                names = [u['name'] for u in users if str(u['id']) in ids]
                dept_names = [x.replace('dept:', '') + " (Dept)" for x in ids if x.startswith('dept:')]
                d['assigned_names'] = ", ".join(names + dept_names)
            try: d['task_list'] = json.loads(d['tasks'])
            except: d['task_list'] = []
            checklists.append(d)
    return render_template('settings.html', theme=THEME, users=users, departments=departments, checklists=checklists)

@app.route('/api/add_user', methods=['POST'])
def add_user():
    try:
        with get_db() as conn: conn.execute("INSERT INTO users (name, pin, role, department) VALUES (?, ?, ?, ?)", (request.form.get('name'), request.form.get('pin'), request.form.get('role'), request.form.get('department'))); conn.commit()
    except: pass
    return redirect(url_for('admin_settings'))

@app.route('/api/delete_user/<int:uid>')
def delete_user(uid):
    with get_db() as conn: conn.execute("DELETE FROM users WHERE id=?", (uid,)); conn.commit()
    return redirect(url_for('admin_settings'))

@app.route('/admin/user_report/<int:user_id>')
def user_report(user_id):
    if session.get('user_role') != 'manager': return "Denied"
    with get_db() as conn:
        user = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        logs = conn.execute("SELECT * FROM attendance WHERE user_id=? ORDER BY timestamp DESC LIMIT 20", (user_id,)).fetchall()
        
        # --- FIX: SPECIFIED 'l.id' TO RESOLVE AMBIGUITY ---
        checks = conn.execute("SELECT l.id, c.title, l.timestamp FROM checklist_logs l JOIN checklists c ON l.checklist_id = c.id WHERE user_id=? ORDER BY l.timestamp DESC LIMIT 10", (user_id,)).fetchall()
        
    return render_template('user_report.html', user_name=user['name'], user_id=user_id, logs=logs, checks=checks)

# ================= SECTION 5: API ENDPOINTS (LOGIC) =================

# --- 5.0: UTILITIES & CONFIG ---
from math import radians, cos, sin, asin, sqrt

# CONFIG
OFFICE_LAT = 12.9716  
OFFICE_LON = 77.5946
MAX_RADIUS_METERS = 500
ALERT_LONG_BREAK_MINS = 30
ALERT_INACTIVE_MINS = 120

def haversine(lon1, lat1, lon2, lat2):
    """Calculate distance in meters"""
    try:
        lon1, lat1, lon2, lat2 = map(float, [lon1, lat1, lon2, lat2])
        lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])
        dlon = lon2 - lon1; dlat = lat2 - lat1
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
        c = 2 * asin(sqrt(a))
        return c * 6371 * 1000
    except: return 0

# --- 5.1: CHECKLIST MANAGEMENT ---
@app.route('/api/save_checklist', methods=['POST'])
def save_checklist():
    users = request.form.getlist('assigned_users')
    depts = request.form.getlist('assigned_depts')
    dept_tags = [f"dept:{d}" for d in depts]
    assigned = ",".join(users + dept_tags) if (users or dept_tags) else "all"
    freq = request.form.get('frequency')
    if freq == 'Weekly': freq = f"Weekly:{request.form.get('day_of_week')}"

    with get_db() as conn:
        if request.form.get('list_id'):
            conn.execute("UPDATE checklists SET title=?, tasks=?, assigned_to=?, frequency=?, trigger_time=? WHERE id=?", 
                         (request.form.get('title'), request.form.get('tasks_json'), assigned, freq, request.form.get('trigger_time'), request.form.get('list_id')))
        else:
            conn.execute("INSERT INTO checklists (title, tasks, assigned_to, frequency, trigger_time) VALUES (?, ?, ?, ?, ?)", 
                         (request.form.get('title'), request.form.get('tasks_json'), assigned, freq, request.form.get('trigger_time')))
        conn.commit()
    return redirect(url_for('admin_settings'))

@app.route('/api/delete_checklist/<int:lid>')
def delete_checklist(lid):
    with get_db() as conn: conn.execute("DELETE FROM checklists WHERE id=?", (lid,)); conn.commit()
    return redirect(url_for('admin_settings'))


@app.route('/api/get_checklist_detail/<int:log_id>')
def get_checklist_detail(log_id):
    with get_db() as conn:
        # Join logs with checklist definitions to get titles and tasks
        row = conn.execute("""
            SELECT c.title, c.tasks, l.data, l.timestamp 
            FROM checklist_logs l 
            JOIN checklists c ON l.checklist_id = c.id 
            WHERE l.id = ?
        """, (log_id,)).fetchone()
        
    if not row: 
        return jsonify({'error': 'Checklist log not found'}), 404
        
    d = dict(row)
    try: 
        d['task_list'] = json.loads(d['tasks'])
        d['answers'] = json.loads(d['data'])
        # Remove raw strings to keep response clean
        del d['tasks']
        del d['data']
    except: 
        return jsonify({'error': 'Data corruption error'}), 500
        
    return jsonify(d)

# --- 5.2: STAFF ACTIONS ---
@app.route('/api/submit_checklist', methods=['POST'])
def submit_checklist():
    if 'user_id' not in session: return jsonify({'error': 'Unauthorized'}), 403
    form_data = request.form.to_dict(); checklist_id = form_data.pop('checklist_id', 0)
    for key, file in request.files.items():
        if file.filename:
            fname = secure_filename(f"{session['user_id']}_{int(datetime.now().timestamp())}_{file.filename}")
            file.save(app.config['UPLOAD_FOLDER'] / fname)
            form_data[key] = fname
    
    now = datetime.now()
    if now.hour < 4: shift_start = (now - timedelta(days=1)).replace(hour=4, minute=0, second=0)
    else: shift_start = now.replace(hour=4, minute=0, second=0)
    shift_end = shift_start + timedelta(hours=24)

    with get_db() as conn:
        existing = conn.execute("SELECT * FROM checklist_logs WHERE user_id=? AND checklist_id=? AND timestamp >= ? AND timestamp < ?", 
                              (session['user_id'], checklist_id, shift_start, shift_end)).fetchone()
        new_hist = {'time': now.strftime('%H:%M'), 'status': 'Updated'}
        
        if existing:
            try: hist = json.loads(existing['edit_history'])
            except: hist = []
            if len(hist) >= 3: return "Error: Max attempts reached.", 403
            new_hist['attempt'] = len(hist) + 1; hist.append(new_hist)
            conn.execute("UPDATE checklist_logs SET data=?, edit_history=?, timestamp=? WHERE id=?", 
                         (json.dumps(form_data), json.dumps(hist), now, existing['id']))
        else:
            new_hist['attempt'] = 1; new_hist['status'] = 'Submitted'
            conn.execute("INSERT INTO checklist_logs (user_id, checklist_id, data, timestamp, edit_history) VALUES (?, ?, ?, ?, ?)", 
                         (session['user_id'], checklist_id, json.dumps(form_data), now, json.dumps([new_hist])))
        conn.commit()
    return redirect(url_for('staff_dashboard'))

@app.route('/api/clock', methods=['POST'])
def clock_action():
    if 'user_id' not in session: return jsonify({"status": "error"}), 401
    data = request.get_json(); req_action = data.get('action')
    lat = data.get('lat', 0); lon = data.get('lon', 0)
    now = datetime.now()
    shift_start_lookup = now - timedelta(hours=18)

    with get_db() as conn:
        last_log = conn.execute("SELECT action FROM attendance WHERE user_id=? AND timestamp > ? ORDER BY timestamp DESC LIMIT 1", 
                              (session['user_id'], shift_start_lookup)).fetchone()
        current_state = 'NOT_STARTED'
        if last_log:
            if last_log['action'] == 'in': current_state = 'ON_DUTY'
            elif last_log['action'] == 'break_start': current_state = 'ON_BREAK'
            elif last_log['action'] == 'break_end': current_state = 'ON_DUTY'
            elif last_log['action'] == 'out': current_state = 'SHIFT_ENDED'
        
        # Validation Logic
        if req_action == 'in' and current_state != 'NOT_STARTED': return jsonify({"status": "error", "msg": "Shift already started"}), 400
        if req_action == 'break_start' and current_state != 'ON_DUTY': return jsonify({"status": "error", "msg": "Must be on duty"}), 400
        if req_action == 'break_end' and current_state != 'ON_BREAK': return jsonify({"status": "error", "msg": "Not on break"}), 400
        if req_action == 'out' and current_state not in ['ON_DUTY', 'ON_BREAK']: return jsonify({"status": "error", "msg": "Shift not active"}), 400

        conn.execute("INSERT INTO attendance (user_id, action, timestamp, lat, lon) VALUES (?, ?, ?, ?, ?)", 
                     (session['user_id'], req_action, now, lat, lon))
        conn.commit()
    return jsonify({"status": "success"})

# --- 5.3: ADMIN LIVE OPS (THE BRAIN) ---
@app.route('/api/get_live_data')
def get_live_data():
    if session.get('user_role') != 'manager': return jsonify({'error': 'Unauthorized'}), 403
    
    now = datetime.now()
    if now.hour < 4: shift_start = (now - timedelta(days=1)).replace(hour=4, minute=0, second=0)
    else: shift_start = now.replace(hour=4, minute=0, second=0)
    
    with get_db() as conn:
        # CONVERT TO DICT IMMEDIATELY
        users = [dict(u) for u in conn.execute("SELECT id, name, role, department FROM users").fetchall()]
        all_logs = [dict(l) for l in conn.execute("SELECT * FROM attendance WHERE timestamp >= ? ORDER BY timestamp ASC", (shift_start,)).fetchall()]
        all_checks = [dict(c) for c in conn.execute("SELECT * FROM checklist_logs WHERE timestamp >= ?", (shift_start,)).fetchall()]
        
        # Fetch Definitions to calculate %
        all_defs = [dict(d) for d in conn.execute("SELECT * FROM checklists").fetchall()]

        staff_data = []
        summary = {'on_duty': 0, 'on_break': 0, 'out': 0, 'issues': 0}
        
        for u in users:
            uid = u['id']
            u_logs = [l for l in all_logs if l['user_id'] == uid]
            u_checks = [c for c in all_checks if c['user_id'] == uid]
            
            # 1. Calc Status & Duration
            work_sec = 0; break_sec = 0
            curr_status = 'out'; last_act = None; 
            curr_in_time = None
            alerts = []

            for log in u_logs:
                try: ts = datetime.strptime(log['timestamp'][:19], '%Y-%m-%d %H:%M:%S')
                except: continue
                last_act = ts
                
                if log['action'] == 'in':
                    curr_in_time = ts; curr_status = 'in'
                elif log['action'] == 'break_start':
                    if curr_in_time: work_sec += (ts - curr_in_time).total_seconds(); curr_in_time = None
                    curr_status = 'break'
                elif log['action'] == 'break_end':
                    curr_in_time = ts; curr_status = 'in'
                elif log['action'] == 'out':
                    if curr_in_time: work_sec += (ts - curr_in_time).total_seconds(); curr_in_time = None
                    curr_status = 'out'
                
                if log.get('lat') and log.get('lon'):
                    dist = haversine(log['lon'], log['lat'], OFFICE_LON, OFFICE_LAT)
                    if dist > MAX_RADIUS_METERS: alerts.append("Geo Violation")

            if curr_status == 'in' and curr_in_time: work_sec += (now - curr_in_time).total_seconds()
            elif curr_status == 'break' and last_act: 
                brk_dur = (now - last_act).total_seconds()
                break_sec += brk_dur
                if brk_dur > (ALERT_LONG_BREAK_MINS * 60): alerts.append("Long Break")

            if curr_status == 'in' and last_act and (now - last_act).total_seconds() > (ALERT_INACTIVE_MINS * 60):
                alerts.append("Inactive")

            if curr_status == 'in': summary['on_duty'] += 1
            elif curr_status == 'break': summary['on_break'] += 1
            else: summary['out'] += 1
            if alerts: summary['issues'] += 1

            # 2. Detailed Checklist Progress
            checklist_status = []
            for check in u_checks:
                # Find the definition
                definition = next((d for d in all_defs if d['id'] == check['checklist_id']), None)
                if definition:
                    try:
                        tasks = json.loads(definition['tasks'])
                        saved = json.loads(check['data'])
                        filled = sum(1 for k in saved.keys() if k.startswith('task_'))
                        total = len(tasks)
                        pct = int((filled/total)*100) if total > 0 else 0
                        checklist_status.append(f"{definition['title']}: {pct}%")
                    except:
                        checklist_status.append("Error")

            staff_data.append({
                'id': uid, 'name': u['name'], 'role': u['role'], 'dept': u['department'] or 'Gen',
                'status': curr_status,
                'work_str': f"{int(work_sec//3600)}h {int((work_sec%3600)//60)}m",
                'break_str': f"{int(break_sec//60)}m",
                'last_seen': last_act.strftime('%H:%M') if last_act else '-',
                'checklists': checklist_status, # Now sending a list of strings
                'alerts': list(set(alerts))
            })

    return jsonify({'summary': summary, 'staff': staff_data})

# --- 5.4: ADMIN CONTROL ACTIONS ---
@app.route('/api/admin/force_checkout/<int:user_id>', methods=['POST'])
def force_checkout(user_id):
    if session.get('user_role') != 'manager': return "Unauthorized", 403
    with get_db() as conn:
        conn.execute("INSERT INTO attendance (user_id, action, timestamp, lat, lon) VALUES (?, ?, ?, ?, ?)", 
                     (user_id, 'out', datetime.now(), '', ''))
        conn.commit()
    return jsonify({'status': 'success'})

@app.route('/api/admin/reset_attempts/<int:log_id>')
def admin_reset_attempts(log_id):
    if session.get('user_role') != 'manager': return "Unauthorized", 403
    with get_db() as conn:
        row = conn.execute("SELECT edit_history FROM checklist_logs WHERE id=?", (log_id,)).fetchone()
        if row:
            try: hist = json.loads(row['edit_history'])
            except: hist = []
            audit = {'attempt': 0, 'time': datetime.now().strftime('%H:%M'), 
                     'status': f"RESET by {session.get('user_name')}", 'previous_attempts': len(hist)}
            conn.execute("UPDATE checklist_logs SET edit_history=? WHERE id=?", (json.dumps([audit]), log_id))
            conn.commit()
    return redirect(url_for('user_report', user_id=request.args.get('uid', 0)))

@app.route('/api/quick_task', methods=['POST'])
def quick_task():
    title = request.form.get('task_title'); assign_to = request.form.get('assign_to')
    if title and assign_to:
        with get_db() as conn:
            conn.execute("INSERT INTO checklists (title, tasks, assigned_to, frequency, trigger_time) VALUES (?, ?, ?, ?, ?)", 
                         (f"Quick Task: {title}", json.dumps([{"title": title, "is_photo": False}]), assign_to, "One-Time", datetime.now().strftime('%H:%M')))
            conn.commit()
    return redirect(url_for('home'))

# ================= SECTION 6: APP EXECUTION =================
if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5001, debug=True)