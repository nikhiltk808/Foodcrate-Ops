from flask import Flask, redirect, url_for
from pathlib import Path
from datetime import datetime, timedelta
import helpers as h
import database as db

# Import Blueprints
from routes_staff import staff_bp
from routes_api import api_bp
from routes_admin import admin_bp

app = Flask(__name__)
app.secret_key = "zion_hills_secure_key"

# --- CONFIG ---
UPLOAD_FOLDER = Path(__file__).parent / "static" / "uploads"
UPLOAD_FOLDER.mkdir(parents=True, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# --- REGISTER BLUEPRINTS ---
app.register_blueprint(staff_bp)
app.register_blueprint(api_bp, url_prefix='/api')
app.register_blueprint(admin_bp)

# --- GLOBAL FILTERS ---
@app.template_filter('date_modify')
def date_modify(date_str, days):
    try:
        dt = datetime.strptime(date_str, '%Y-%m-%d')
        return (dt + timedelta(days=int(days))).strftime('%Y-%m-%d')
    except: return date_str

@app.route('/')
def index():
    return redirect(url_for('admin.home'))

    # --- TEMPORARY DATABASE FIXER ---
@app.route('/update_db')
def update_db():
    try:
        db.init_db() # This runs the table creation code in database.py
        return "<h1>✅ Database Updated Successfully!</h1><p>The 'duty_instructions' table has been created.</p><a href='/'>Go to Dashboard</a>"
    except Exception as e:
        return f"<h1>❌ Error</h1><p>{str(e)}</p>"

        # --- TEMPORARY DB FIXER ---
@app.route('/fix_db_now')
def fix_db_now():
    import sqlite3
    conn = db.get_db()
    c = conn.cursor()
    try:
        # Try adding the missing column
        c.execute("ALTER TABLE todos ADD COLUMN due_date TEXT")
        conn.commit()
        return "<h1>✅ Success!</h1> <p>Database repaired. The 'due_date' column was added.</p> <a href='/'>Go to Dashboard</a>"
    except Exception as e:
        return f"<h1>⚠️ Info</h1> <p>{str(e)}</p> <p>(If it says 'duplicate column', that means it's already fixed!)</p> <a href='/'>Go to Dashboard</a>"

if __name__ == '__main__':
    db.init_db()
    app.run(host='0.0.0.0', port=5001, debug=True)