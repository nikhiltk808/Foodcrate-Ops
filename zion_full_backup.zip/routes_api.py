from flask import Blueprint, request, jsonify, session
from datetime import datetime, timedelta
import os
import database as db
import helpers as h

api_bp = Blueprint('api', __name__)

# --- ROBUST PATH CONFIGURATION ---
# Get the folder where this script (routes_api.py) lives
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# Force the evidence folder to be inside the static folder of this directory
EVIDENCE_FOLDER = os.path.join(BASE_DIR, 'static', 'evidence')

# Create it if it doesn't exist
if not os.path.exists(EVIDENCE_FOLDER):
    os.makedirs(EVIDENCE_FOLDER)

# --- CLOCK ---
@api_bp.route('/clock', methods=['POST'])
def clock():
    if 'user_id' not in session: return jsonify({'error':'Auth'}), 401
    d = request.get_json()
    with db.get_db() as conn:
        conn.execute("INSERT INTO attendance (user_id, action, timestamp, lat, lon) VALUES (?, ?, ?, ?, ?)",
                     (session['user_id'], d.get('action'), datetime.now()+h.IST_OFFSET, d.get('lat'), d.get('lon')))
        conn.commit()
    return jsonify({"status": "success"})

# --- TASKS (PHOTO FIX) ---
@api_bp.route('/submit_checklist', methods=['POST'])
def submit():
    if 'user_id' not in session: return "Unauthorized", 401
    try:
        uid = session['user_id']
        cid = request.form.get('checklist_id')
        conn = db.get_db()
        ts = (datetime.now() + h.IST_OFFSET).strftime('%Y-%m-%d %H:%M:%S')

        # 1. Handle Checkboxes
        for k, v in request.form.items():
            if k != 'checklist_id':
                conn.execute("INSERT INTO checklist_logs (checklist_id, user_id, task_name, data, timestamp) VALUES (?, ?, ?, ?, ?)",
                             (cid, uid, k, 'done', ts))

        # 2. Handle Photos (Fixed Path)
        for key in request.files:
            file = request.files[key]
            if file and file.filename != '':
                # Clean filename
                clean_key = key.replace(" ", "_").replace("/", "-")
                filename = f"{uid}_{cid}_{clean_key}_{int(datetime.now().timestamp())}.jpg"

                # SAVE TO ABSOLUTE PATH
                save_path = os.path.join(EVIDENCE_FOLDER, filename)
                file.save(save_path)

                # STORE RELATIVE WEB URL
                db_url = f"/static/evidence/{filename}"

                conn.execute("INSERT INTO checklist_logs (checklist_id, user_id, task_name, task_type, photo_proof, timestamp) VALUES (?, ?, ?, 'PHOTO', ?, ?)",
                             (cid, uid, key, db_url, ts))

        conn.commit()
        conn.close()
        return "Saved", 200
    except Exception as e:
        return str(e), 500

# --- TO-DO LIST ---
@api_bp.route('/todo/add', methods=['POST'])
def add_todo():
    if 'user_id' not in session: return "Auth", 401
    txt = request.form.get('task')
    due = request.form.get('due_date')
    now_str = (datetime.now() + h.IST_OFFSET).strftime('%Y-%m-%d %H:%M:%S')
    with db.get_db() as conn:
        conn.execute("INSERT INTO todos (user_id, task, status, created_at, due_date) VALUES (?, ?, ?, ?, ?)",
                     (session['user_id'], txt, 'pending', now_str, due))
        conn.commit()
    return "OK", 200

@api_bp.route('/todo/toggle', methods=['POST'])
def toggle_todo():
    if 'user_id' not in session: return "Auth", 401
    tid = request.form.get('id')
    with db.get_db() as conn:
        conn.execute("UPDATE todos SET status='archived' WHERE id=?", (tid,))
        conn.commit()
    return "OK", 200

@api_bp.route('/todo/delete', methods=['POST'])
def delete_todo():
    if 'user_id' not in session: return "Auth", 401
    with db.get_db() as conn:
        conn.execute("DELETE FROM todos WHERE id=?", (request.form.get('id'),))
        conn.commit()
    return "OK", 200

# --- ADMIN CHARTS ---
@api_bp.route('/get_live_data')
def get_live_data():
    if session.get('user_role') != 'manager': return jsonify({'error': 'Unauthorized'}), 403
    try:
        today = datetime.now() + h.IST_OFFSET
        shift_start = today.replace(hour=4, minute=0, second=0)
        if today.hour < 4: shift_start -= timedelta(days=1)

        with db.get_db() as conn:
            users = [dict(u) for u in conn.execute("SELECT id, name, role FROM users").fetchall()]
            logs = [dict(l) for l in conn.execute("SELECT * FROM attendance WHERE timestamp >= ? ORDER BY timestamp ASC", (shift_start,)).fetchall()]

            staff_data = []; summary = {'on_duty': 0, 'on_break': 0, 'out': 0}
            for u in users:
                u_logs = [l for l in logs if l['user_id'] == u['id']]
                status = 'out'; last_seen = '-'
                if u_logs:
                    last = u_logs[-1]; last_seen = last['timestamp'][11:16]
                    if last['action'] in ['in', 'break_end']: status = 'in'
                    elif last['action'] == 'break_start': status = 'break'

                if status == 'in': summary['on_duty'] += 1
                elif status == 'break': summary['on_break'] += 1
                else: summary['out'] += 1
                staff_data.append({'id': u['id'], 'name': u['name'], 'role': u['role'], 'status': status, 'last_seen': last_seen})

            return jsonify({'summary': {'on_duty': {'val': summary['on_duty']}, 'on_break': {'val': summary['on_break']}, 'out': {'val': summary['out']}}, 'staff': staff_data})
    except: return jsonify({'staff': []})

@api_bp.route('/request_refill', methods=['POST'])
def request_refill():
    cid = request.form.get('checklist_id'); uid = session['user_id']
    with db.get_db() as conn:
        conn.execute("INSERT INTO requests (user_id, checklist_id, request_type, status, timestamp) VALUES (?, ?, 'REFILL', 'PENDING', ?)", (uid, cid, datetime.now()))
        conn.commit()
    return "OK", 200

@api_bp.route('/acknowledge', methods=['POST'])
def acknowledge():
    if 'user_id' not in session: return "Unauthorized", 401
    aid = request.form.get('announcement_id')
    with db.get_db() as conn:
        conn.execute("INSERT OR IGNORE INTO acknowledgments (user_id, announcement_id, timestamp) VALUES (?, ?, ?)",
                     (session['user_id'], aid, datetime.now()))
        conn.commit()
    return "OK", 200